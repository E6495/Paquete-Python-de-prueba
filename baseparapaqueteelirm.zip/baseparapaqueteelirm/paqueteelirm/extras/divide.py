def divide(a, b):
    if b != 0:
        return a / b
    else:
        return "Error: No se puede dividir por cero."